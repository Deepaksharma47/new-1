
import express from "express"
import { dbconnect } from "./config/dbconnect";
import app from "./index"


// setSocket(server)

dbconnect();

const port = process.env.PORT;
app.listen(port, ()=>{
    console.log("Server is running on port : ",port)
})

