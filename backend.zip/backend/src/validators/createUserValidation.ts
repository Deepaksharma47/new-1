import { Request, Response, NextFunction } from "express";
import {check,} from "express-validator"
import {validateUser} from "../middlewares/feildValidator"
export  const createPostValidator = [
    check("firstName")
        .not()
        .isEmpty()
        .withMessage("First Name is required"),
    check("lastName")
        .not()
        .isEmpty()
        .withMessage("Last Name is required"),
    check("brand")
        .not()
        .isEmpty()
        .withMessage("Brand Name is required"),
    check("email")
        .not()
        .isEmpty()
        .withMessage("Email is empty")
        .isEmail()
        .withMessage("Email is required"),
    check("phoneNo")
        .not()
        .isEmpty()
        .withMessage("Contact  Number is required"),

    check("user_type")
        .not()
        .isEmpty()
        .withMessage("User Type is required")
        .isIn(["costumer", "retailer"])
        .withMessage("Role should be selected"),
        

    (req:Request, res:Response, next:NextFunction) =>{
        validateUser(req, res, next);
    }
];

