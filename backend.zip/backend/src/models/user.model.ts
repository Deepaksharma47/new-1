import { DataTypes } from "sequelize";
import sequelize from "../config/dbconnect";
import Product from "./product.model";

const User = sequelize.define("user", {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true
    },
    firstName: {
        type: DataTypes.STRING,
        allowNull: true
    },
    lastName: {
        type: DataTypes.STRING,
        allowNull: true
    },
    brand: {
        type: DataTypes.STRING,
        allowNull: true
    },
    // address: {
    //     type: DataTypes.STRING,
    //     allowNull: true
    // },
    email: {
        type: DataTypes.STRING,
        allowNull: true
    },
    phoneNo: {
        type: DataTypes.STRING,
        allowNull: true
    },
    password: {
        type: DataTypes.STRING,
        allowNull: true
    },
    brandLogo: {
        type: DataTypes.STRING,
        allowNull: true
    },
    profileImage: {
        type: DataTypes.STRING,
        allowNull: true
    },
})


User.hasMany(Product,{
    sourceKey:"id",
    foreignKey:"userId",
    as:"products"
})
Product.belongsTo(User,{
    targetKey:"id",
    foreignKey:"userId",
    as:"user"
})

export default User;