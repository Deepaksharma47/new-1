// import UserDetail from "./userDetail";
// import AddressDetail from "./addressModel";

// // UserDetail.associate();
// // AddressDetail.associate();

// const associateModels = () => {

//     UserDetail.associate();
  
//     AddressDetail.associate();
  
//   };

//   export { UserDetail, AddressDetail, associateModels };