import React from 'react';

interface PaginationCountProps {
  totalProducts: number;
  currentPage: number; // Add currentPage prop
  setCurrentPage: (page: number) => void;
  setItems:(page:number) => void;
  
}

const PaginationCount: React.FC<PaginationCountProps> = ({ totalProducts, currentPage, setCurrentPage ,setItems }) => {
  const totalPages = Math.ceil(totalProducts / 5);
  console.log(totalProducts)

  console.log("currentPagecurrentPage",currentPage)

  return (
    <div>
      <nav aria-label="Page navigation example">
        <ul className="list-style-none flex">
          <li>
            <button
              className="relative block rounded bg-transparent px-3 py-1.5 text-sm text-neutral-600 transition-all duration-300 hover:bg-neutral-100 dark:text-white dark:hover:bg-neutral-700 dark:hover:text-white"
              onClick={() => setCurrentPage(Math.max(currentPage - 1, 0))}
              disabled={currentPage === 0}
            >
              Previous
            </button>
          </li>
          {Array.from({ length: totalPages }).map((_, i) => (
            <li key={i}>
              <button
                className="relative block rounded bg-transparent px-3 py-1.5 text-sm text-neutral-600 transition-all duration-300 hover:bg-neutral-100 dark:text-white dark:hover:bg-neutral-700 dark:hover:text-white"
                onClick={() => setCurrentPage(i)}
              >
                {i + 1}
              </button>
            </li>
          ))}
          <li>
            <button
              className="relative block rounded bg-transparent px-3 py-1.5 text-sm text-neutral-600 transition-all duration-300 hover:bg-neutral-100 dark:text-white dark:hover:bg-neutral-700 dark:hover:text-white"
              onClick={() => setCurrentPage(Math.min(currentPage + 1, totalPages - 1))}
              disabled={currentPage === totalPages - 1}
            >
              Next
            </button>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default PaginationCount;
