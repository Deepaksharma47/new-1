import React, { useState } from 'react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (formData: FormData) => void;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, onAdd }) => {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [quantity, setQuantity] = useState(0);
  const [status, setStatus] = useState<'draft' | 'publish'>('draft');
  const [price, setPrice] = useState(0);
  const [image, setImage] = useState<File | null>(null);

  const handleAdd = () => {
    const formData = { name, category, quantity, status, price, image };
    onAdd(formData);
    onClose(); // Close modal after adding
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gray-500 bg-opacity-75">
      <div className="bg-white rounded-lg p-6 w-96">
        <h2 className="text-lg font-semibold mb-4">Add Item</h2>

        <div className="mb-4">
          <label className="block mb-1">Name</label>
          <input
            type="text"
            className="border rounded px-3 py-2 w-full"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        <div className="mb-4">
          <label className="block mb-1">Category</label>
          <input
            type="text"
            className="border rounded px-3 py-2 w-full"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          />
        </div>

        <div className="mb-4">
          <label className="block mb-1">Quantity</label>
          <input
            type="number"
            className="border rounded px-3 py-2 w-full"
            value={quantity}
            onChange={(e) => setQuantity(Number(e.target.value))}
          />
        </div>

        <div className="mb-4">
          <label className="block mb-1">Status</label>
          <select
            className="border rounded px-3 py-2 w-full"
            value={status}
            onChange={(e) => setStatus(e.target.value as 'draft' | 'publish')}
          >
            <option value="draft">Draft</option>
            <option value="publish">Publish</option>
          </select>
        </div>

        <div className="mb-4">
          <label className="block mb-1">Price</label>
          <input
            type="number"
            className="border rounded px-3 py-2 w-full"
            value={price}
            onChange={(e) => setPrice(Number(e.target.value))}
          />
        </div>

        <div className="mb-4">
          <label className="block mb-1">Image</label>
          <input
            type="file"
            className="border rounded px-3 py-2 w-full"
            onChange={(e) => {
              if (e.target.files) {
                setImage(e.target.files[0]);
              }
            }}
          />
        </div>

        <div className="flex justify-end">
          <button
            className="mr-2 bg-gray-300 rounded px-4 py-2"
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            className="bg-blue-500 text-white rounded px-4 py-2"
            onClick={handleAdd}
          >
            Add
          </button>
        </div>
      </div>
    </div>
  );
};

export default Modal;
