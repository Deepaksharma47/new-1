import { useMutation } from "@tanstack/react-query";
import { toast } from "react-toastify";
import axios from "axios";
const BASE_URL =import.meta.env.VITE_API_URL;



export const useResisterContext = (navigate:any) => {
    return (
        useMutation({
            mutationFn: async (data) => {
                return await axios.post(  BASE_URL+"/signup", data)
            },
            onSuccess:(data) =>{
                localStorage.clear();
                navigate("/login")
                toast.success("Successfully Signed Up")
            }
        })
    )
}