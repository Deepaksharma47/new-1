import { useMutation } from "@tanstack/react-query"
import axios from "axios"
import { toast } from "react-toastify";
const BASE_URL =import.meta.env.VITE_API_URL;

export const useLoginContext = (navigate:any) =>{

    return(
         useMutation({
            mutationFn : async(data) =>{
                return await axios.post(BASE_URL+"/login",data)
            },
            onSuccess : (data) =>{
                // dispatch(setUser(data.data.user))
                // dispatch(setStayLogin(stay)) 
                // dispatch(setToken(data.data.token))
                // dispatch(setUserType(data.data.user.user_type))
                toast.success("Login Successfully")
                console.log(data)
                navigate("/dashboard/products")
            }
        })
    )
}