import './App.css'
import Login from './pages/Login'
import { Routes, Route } from 'react-router-dom'
import Products from './pages/Products'
import Dashboard from './pages/Dashboard'
import Signup from './pages/Signup'

function App() {

  return (
    <>
    <Routes>
      <Route path='/dashboard' element={<Dashboard />} >
        <Route path='products'  element={<Products />} />
      </Route>

      <Route  path='/login' element={<Login />} />
      <Route  path='/' element={<Signup />} />
    </Routes>

    </>
  )
}

export default App
