export interface SignUpFormData {
    firstName: string;
    lastName: string;
    brand: string;
    email: string;
    brandLogo: File | null; // Assuming brandLogo is a File object or null
    phoneNo: string;
    user_type: 'retailer' | 'costumer';
    profileImage:File | null // Adjust the options based on your requirements
  }

export interface LoginFormData{
    email: string;
    password: string;
}