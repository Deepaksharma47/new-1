import  { useState } from 'react'
import { MdEdit } from "react-icons/md";
import { RiDeleteBin6Line } from "react-icons/ri";
import { FaEye } from "react-icons/fa";
import PaginationCount from '../components/PaginationCount';
import { MdOutlineYoutubeSearchedFor } from "react-icons/md";

const packageData = [
  {
    name: 'Package 1',
    invoiceDate:'123456',
    status:"Paid",
    price:"11"

  }
]

const Products = () => {
  const [items, setItems] = useState([])
  const [searchInput, setSearchInput]  = useState("")
  const [totalProducts, setTotalProducts] = useState(25)
  const  [currentPage, setCurrentPage] = useState(1)
  

  return (
    <div>
      <div className="rounded-sm border border-stroke bg-white px-3 py-4  shadow-default dark:border-strokedark dark:bg-boxdark sm:px-7.5 xl:pb-1">
      <div className="max-w-full mx-auto overflow-x-auto">
        <div className=' flex flex-row justify-around'>
        <div className="flex items-center space-x-2 m-1">
          <label htmlFor="searchInput" className="text-gray-700 font-medium">
            Search:
          </label>
          <input
            type="text"
            id="searchInput"
            name="searchInput"
            placeholder="Search here"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="border border-gray-300 rounded-md px-4 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-150 ease-in-out"
          />
          <button type='button' className=" text-2xl hover:scale-105 hover:text-cyan-700"><MdOutlineYoutubeSearchedFor/></button>
        </div>
          <button className='font-semibold text-white bg-blue-600 hover:scale-95 hover:bg-blue-800 transition-all duration-200 px-2 py-1 rounded-2xl shadow-xl'
           >Add Product</button>
        </div>
        <table className="w-full table-auto">
          <thead>
            <tr className="bg-gray-2 text-left dark:bg-meta-4">
              <th className="min-w-[220px] py-4 px-4 font-medium text-black dark:text-white xl:pl-11">
                Package
              </th>
              <th className="min-w-[150px] py-4 px-4 font-medium text-black dark:text-white">
                Invoice date
              </th>
              <th className="min-w-[120px] py-4 px-4 font-medium text-black dark:text-white">
                Status
              </th>
              <th className="py-4 px-4 font-medium text-black dark:text-white">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {packageData.map((packageItem, key) => (
              <tr key={key} className=' hover:scale-105 bg-slate-300 transition-all duration-200 '>
                <td className="border-b border-[#eee] py-5 px-4 pl-9 dark:border-strokedark xl:pl-11">
                  <h5 className="font-medium text-black dark:text-white">
                    {packageItem.name}
                  </h5>
                  <p className="text-sm">${packageItem.price}</p>
                </td>
                <td className="border-b border-[#eee] py-5 px-4 dark:border-strokedark">
                  <p className="text-black dark:text-white">
                    {packageItem.invoiceDate}
                  </p>
                </td>
                <td className="border-b border-[#eee] py-5 px-4 dark:border-strokedark">
                  <p
                    className={`inline-flex rounded-full  py-1 px-3 text-sm font-medium ${
                      packageItem.status === 'Active'
                        ? ' bg-green-600 text-white'
                        : packageItem.status === 'Inactive'
                        ? 'bg-red-600 text-white'
                        : 'bg-warning text-warning'
                    }`}
                  >
                    {packageItem.status}
                  </p>
                </td>
                <td className="border-b py-5 px-4 dark:border-strokedark">
                  <div className="flex items-center space-x-3.5">
                    <button className=" text-xl hover:text-red-600">
                      <RiDeleteBin6Line/>
                    </button>
                    <button className="hover:text-green-500 text-xl">
                      <FaEye/>
                    </button>
                    <button className="hover:text-blue-700 text-black text-xl">
                      <MdEdit/>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className=' w-fit mx-auto'>
       <PaginationCount totalProducts={totalProducts} setItems={setItems} setCurrentPage={setCurrentPage} currentPage={currentPage}/>
      </div>
    </div>
    </div>
  )
}

export default Products