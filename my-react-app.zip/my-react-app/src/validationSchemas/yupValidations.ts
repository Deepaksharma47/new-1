import * as Yup from 'yup';

const SUPPORTED_IMAGE : Array<string> = [ 'image/png', 'image/jpeg', 'image/jpg'];

export const customerSignupValidationSchema = Yup.object({
    firstName: Yup.string()
            .required("Please enter your first name")
            .min(3, "Greater than 3 digits"),
    lastName:Yup.string().required("Last Name Required"),
    brand: Yup.string()
        .min(3, 'Username must be at least 3 characters')
        .required('name is required'),
    email: Yup.string()
        .email('Invalid email address')
        .required('Email is required'),
    phoneNo: Yup.string().required(" Enter Your Contact No.").matches(/^[1-9][0-9]{9}$/, "Must be integer and 10 in length"),
    brandLogo : Yup.mixed().required("select brand logo")
        .test("fileFormat","only png and jpeg are allowed",(value) => value &&  value instanceof File  && SUPPORTED_IMAGE.includes((value).type) ),
    profileImage : Yup.mixed().required("select profile image")
        .test("fileFormat","only png and jpeg are allowed",(value) => value &&  value instanceof File  && SUPPORTED_IMAGE.includes((value).type) ),
});

export const loginValidationSchema = () => {
    return(
        Yup.object().shape({
            email: Yup.string()
              .email('Invalid email format')
              .required('Email is required'),
              
            password: Yup.string()
              .min(8, 'Password must be at least 8 characters')
              .required('Password is required')
          })
    )
}